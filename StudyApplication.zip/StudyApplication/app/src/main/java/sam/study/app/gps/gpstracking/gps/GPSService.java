package sam.study.app.gps.gpstracking.gps;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import sam.study.app.gps.gpstracking.ConstantsData;
import sam.study.app.gps.gpstracking.db.GPSDatabaseHandler;
import sam.study.app.gps.gpstracking.db.GPSRecord;

public class GPSService extends Service {

    Timer mTimer;
    private GPSDatabaseHandler mGPSDatabase;
    float mMinDistanceToFetchGPS;
    long mMinTimeToFetchGPS;
    boolean isAccuracyFine;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Bundle bundle = intent.getBundleExtra("bundle");
        mMinDistanceToFetchGPS = bundle.getFloat(ConstantsData.MIN_DISTANCE_IN_METER_TO_FETCH_GPS, 2);
        mMinTimeToFetchGPS = bundle.getLong(ConstantsData.MIN_TIME_IN_MILISEC_TO_FETCH_GPS, 1000);
        isAccuracyFine = bundle.getBoolean(ConstantsData.ACCURACY_CRITERIA_FLAG, false);
        mGPSDatabase = new GPSDatabaseHandler(this);

        Log.i("####", "onStartCommand : " + ConstantsData.MIN_DISTANCE_IN_METER_TO_FETCH_GPS);

        final Handler handler = new Handler();
        mTimer = new Timer();
        TimerTask task = new TimerTask() {

            @Override
            public void run() {
                handler.post(new Runnable() {

                    @Override
                    public void run() {
                        gpsTracking(mMinDistanceToFetchGPS, mMinTimeToFetchGPS, isAccuracyFine);
                    }
                });

            }
        };

        mTimer.schedule(task, 0, mMinTimeToFetchGPS); // gps tracking per 10 seconds

        return Service.START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * Track GPS location as per given <strong>minDistance</strong> and <strong>minTime</strong>.
     * It will update the records after every particular time interval
     *
     * @param minDistance - minimum distance between location updates, in meters
     * @param minTime     - minimum time interval between location updates, in milliseconds
     */
    public void gpsTracking(float minDistance, long minTime, boolean isAccuracyFine) {
        GPSTracker gpsTracker = new GPSTracker(getApplicationContext(), minDistance, minTime, isAccuracyFine);

        Log.i("####", "canGetLocation : " + gpsTracker.canGetLocation);
        if (gpsTracker.canGetLocation) {

            Toast.makeText(
                    getApplicationContext(),
                    "Locations :" + "\nLat :" + gpsTracker.getLatitude()
                            + "\n Long :" + gpsTracker.getLongitude()
                    , Toast.LENGTH_SHORT)
                    .show();

            Log.i("####", "long & lat  : " + gpsTracker.getLongitude() +
                    " >> " + gpsTracker.getLatitude());
            updateGPSRecord("" + gpsTracker.getLongitude(),
                    "" + gpsTracker.getLatitude());
        } else {
            Log.i("####", "canGetLocation : inside else");
        }
    }

    @Override
    public void onDestroy() {
        mTimer.cancel();
        mTimer.purge();
        Log.d("TAG", "Service Destroyed");
        super.onDestroy();
    }

    // Inserting GPS Record
    private void updateGPSRecord(String longitude, String lattitude) {

        Log.d("TAG", "Updating...");

        String currentTime = java.text.DateFormat.getDateTimeInstance().format(
                Calendar.getInstance().getTime());

        mGPSDatabase.addGPSRecord(new GPSRecord(longitude, lattitude,
                currentTime));

        List<GPSRecord> gpsRecordsList = mGPSDatabase.getAllGPSRecords();
        Toast.makeText(getApplicationContext(),
                "Database Updated : count : " + gpsRecordsList.size(),
                Toast.LENGTH_SHORT).show();
    }

}
