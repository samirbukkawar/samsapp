package sam.study.app.gifdemo;

import android.app.Activity;
import android.app.IntentService;
import android.app.Service;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebView;

import sam.study.app.R;

public class GIFDemoAtivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gif_demo);

        Service service;
        IntentService intentService;

        WebView webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("file:///android_asset/loading.gif");

    }
}
