package sam.study.app.websocket;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import sam.study.app.R;

public class WebSocketDemoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_socket_demo);
    }

    public void submitClick(View view) {
        Log.i("####", "submitClick");

        WebSocketConnector connector = new WebSocketConnector();
        connector.ConnectWebSocket();

    }
}
