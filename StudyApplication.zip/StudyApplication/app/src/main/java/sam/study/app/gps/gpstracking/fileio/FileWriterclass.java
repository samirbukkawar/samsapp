package sam.study.app.gps.gpstracking.fileio;

import android.content.Context;
import android.database.Cursor;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

import sam.study.app.gps.gpstracking.db.GPSDatabaseHandler;

/**
 * This class is responsible to extract the data from SQLite Database and
 * generate CSV file accordingly
 *
 * @author Shahnawaz Jafri/Samir Bukkawar
 */
public class FileWriterclass {

    private String FOLDER_NAME = "GPSFiles";
    private String FILE_NAME;
    private String FILE_EXTENSION = ".csv";
    private GPSDatabaseHandler mGPSDatabase;

    public FileWriterclass(String fOLDER_NAME, String fILE_NAME) {
        super();
        FOLDER_NAME = fOLDER_NAME;
        FILE_NAME = fILE_NAME;
    }

    public void fileWrite(Context con) {


        Log.d("####", "fileWrite ");

        mGPSDatabase = new GPSDatabaseHandler(con);

        Cursor cursor = mGPSDatabase.getGPSRecords();

        if (cursor.getCount() < 1)
            return;

        File newDirName = new File(Environment.getExternalStorageDirectory()
                .getAbsoluteFile(), FOLDER_NAME);
        if (newDirName.mkdir() || newDirName.isDirectory()) {

            Calendar c = Calendar.getInstance();
            // int year = c.get(Calendar.YEAR);
            int day = c.get(Calendar.DATE);
            // int weeekday = c.get(Calendar.DAY_OF_WEEK_IN_MONTH);
            int hour = c.get(Calendar.HOUR);
            int min = c.get(Calendar.MINUTE);
            int seconds = c.get(Calendar.SECOND);

            String fileName = FILE_NAME + "_" + day + "_" + hour + min
                    + seconds + "" + FILE_EXTENSION;
            File newFileName = new File(newDirName.getAbsoluteFile(), fileName);

            Log.d("####", "newDirName " + newDirName);
            Log.d("####", "File Name " + newFileName);
            FileWriter outFile;
            int columnCount = 4; // 4 - for GPS ; 7 - Acceleration
            try {
                outFile = new FileWriter(newFileName);
                // PrintWriter out = new PrintWriter(outFile);

                for (int i = 0; i < columnCount; i++) {

                    outFile.append(cursor.getColumnName(i));
                    outFile.append(",");
                }

                outFile.append("\r\n");
                while (cursor.moveToNext()) {

                    for (int i = 0; i < columnCount; i++) {

                        outFile.append(cursor.getString(i) + ",");
                    }

                    outFile.append("\r\n");
                }
                // Close
                outFile.close();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        // Reset Database
        mGPSDatabase.resetAllRecords();
    }
}
