package sam.study.app.recycleviewdemo;

import android.view.View;

/**
 * Created by samir.s.bukkawar on 11/18/2016.
 */

public interface RecycleClickListner {
    public abstract void OnClick(View view, int position);
}
