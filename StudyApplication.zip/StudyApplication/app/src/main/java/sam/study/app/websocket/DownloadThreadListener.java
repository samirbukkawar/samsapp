package sam.study.app.websocket;

public interface DownloadThreadListener {

	void handleDownloadThreadUpdate();
}
