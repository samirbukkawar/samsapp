package sam.study.app.gps.gpstracking;

/**
 * This class is for constants used in the application. 
 * 
 * @author Shahnawaz Jafri/Samir Bukkawar
 * 
 */

public final class ConstantsData {

	public static final String MIN_DISTANCE_IN_METER_TO_FETCH_GPS = "MIN_DISTANCE_IN_METER_TO_FETCH_GPS";

	public static final String MIN_TIME_IN_MILISEC_TO_FETCH_GPS = "MIN_TIME_IN_MILISEC_TO_FETCH_GPS";

	// Folder Name in which we want to generate the files
	public static final String FOLDER_NAME = "FOLDER_NAME";

	// File prefix for the file name
	public static final String FILE_NAME_PREFIX = "FILE_NAME_PREFIX";

	// File creation time
	public static final String FILE_CREATION_TIME_INTERVAL_IN_MILISEC = "FILE_CREATION_TIME_INTERVAL_IN_MILISEC";

	// Set the criteria for flag
	public static final String ACCURACY_CRITERIA_FLAG = "ACCURACY_CRITERIA_FLAG";
}
