package sam.study.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import sam.study.app.HandlerLooper.HandlerLooperActivity;
import sam.study.app.ImageDemo.ImageDemoActivity;
import sam.study.app.battery.BatteryStatusActivity;
import sam.study.app.broadcastdemo.BroadcastDemoActivity;
import sam.study.app.crittercism.CrittercismDemoActivity;
import sam.study.app.customfont.CustomFontSizeActivity;
import sam.study.app.encryption.EncryptionActivity;
import sam.study.app.gifdemo.GIFDemoAtivity;
import sam.study.app.gps.GPSDemoActivity;
import sam.study.app.listview.ListActivity;
import sam.study.app.realmdb.RealmDemoAvtivity;
import sam.study.app.recycleviewdemo.RecycleViewActivity;
import sam.study.app.runtimepermission.RuntimePermissionActivity;
import sam.study.app.screensaver.ScreenSaverActivity;
import sam.study.app.spellcheck.SpellCheckActivity;
import sam.study.app.websocket.WebSocketDemoActivity;


public class MainActivity extends Activity {

    private ListView listView;
    private String demoNameArr[] = {"List View Demo",
            "Recycle View Demo",
            "Spell Check Demo",
            "Encrypt/Decrypt",
            "Battery Status",
            "Broadcast Receiver",
            "Crittercism Demo",
            "GIF Demo",
            "Custom Font Demo",
            "Realm DB Demo",
            "Web Socket Demo",
            "Handler Looper Demo",
            "ScreenSaver Demo",
            "GPS Demo",
            "Runtime Permission Demo",
            "Image View Demo"};
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        listView = (ListView) findViewById(R.id.myListView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, demoNameArr);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(mContext, " >> " + demoNameArr[i], Toast.LENGTH_SHORT).show();
                Intent intent = null;
                switch (i) {
                    case 0:
                        intent = new Intent(MainActivity.this, ListActivity.class);
                        break;
                    case 1:
                        intent = new Intent(MainActivity.this, RecycleViewActivity.class);
                        break;
                    case 2:
                        intent = new Intent(MainActivity.this, SpellCheckActivity.class);
                        break;
                    case 3:
                        intent = new Intent(MainActivity.this, EncryptionActivity.class);
                        break;
                    case 4:
                        intent = new Intent(MainActivity.this, BatteryStatusActivity.class);
                        break;
                    case 5:
                        intent = new Intent(MainActivity.this, BroadcastDemoActivity.class);
                        break;
                    case 6:
                        intent = new Intent(MainActivity.this, CrittercismDemoActivity.class);
                        break;
                    case 7:
                        intent = new Intent(MainActivity.this, GIFDemoAtivity.class);
                        break;
                    case 8:
                        intent = new Intent(MainActivity.this, CustomFontSizeActivity.class);
                        break;
                    case 9:
                        intent = new Intent(MainActivity.this, RealmDemoAvtivity.class);
                        break;
                    case 10:
                        intent = new Intent(MainActivity.this, WebSocketDemoActivity.class);
                        break;
                    case 11:
                        intent = new Intent(MainActivity.this, HandlerLooperActivity.class);
                        break;
                    case 12:
                        intent = new Intent(MainActivity.this, ScreenSaverActivity.class);
                        break;
                    case 13:
                        intent = new Intent(MainActivity.this, GPSDemoActivity.class);
                        break;
                    case 14:
                        intent = new Intent(MainActivity.this, RuntimePermissionActivity.class);
                        break;
                    case 15:
                        intent = new Intent(MainActivity.this, ImageDemoActivity.class);
                        break;
                    default:
                        Toast.makeText(mContext, " Activity not available ", Toast.LENGTH_SHORT).show();
                        return;
                }
                if (intent != null)
                    startActivity(intent);
            }
        });
    }
}