package sam.study.app.listview;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import sam.study.app.R;

/**
 * Created by samir.s.bukkawar on 11/15/2016.
 */

public class CustomAdapter extends BaseAdapter implements View.OnClickListener {

    private LayoutInflater mInflator;
    private Context mContext;
    private String mTitleArray[];
    private String mSubTitleArray[];

    public CustomAdapter(Activity activity, String[] titleArray, String[] subTitleArray) {

        mTitleArray = titleArray;
        mSubTitleArray = subTitleArray;
        mContext = activity;
        mInflator = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mTitleArray.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(mContext, " >> ", Toast.LENGTH_SHORT).show();
    }

    public class ViewHolder {
        ImageView iconViewHolder;
        TextView titleViewHolder, subTitleViewHolder;
    }

    @Override
    public View getView(final int position, View converterView, ViewGroup viewGroup) {
        ViewHolder holder = new ViewHolder();
        View rowView = mInflator.inflate(R.layout.my_custom_list_row, null);

        holder.iconViewHolder = (ImageView) rowView.findViewById(R.id.iconView);
        holder.titleViewHolder = (TextView) rowView.findViewById(R.id.tvTitleText);
        holder.subTitleViewHolder = (TextView) rowView.findViewById(R.id.tvSubTitleText);

        holder.titleViewHolder.setText(mTitleArray[position]);
        holder.subTitleViewHolder.setText(mSubTitleArray[position]);
        holder.iconViewHolder.setImageResource(R.drawable.ic_launcher);

        holder.titleViewHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, mTitleArray[position] + " : " + mSubTitleArray[position], Toast.LENGTH_SHORT).show();
            }
        });

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, mTitleArray[position] + " : " + mSubTitleArray[position], Toast.LENGTH_SHORT).show();
            }
        });

        return rowView;
    }
}