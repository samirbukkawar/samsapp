package sam.study.app.customfont;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import sam.study.app.R;

public class CustomFontSizeActivity extends Activity {

    private EditText mSampleText;
    private TextFitTextView mCustomTextView;
    private TextView mDefaultTextView;
    private String mSampleStr;
    private Button mCustomButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_font_size);

        mSampleText = (EditText) findViewById(R.id.etSampleText);
        mCustomTextView = (TextFitTextView) findViewById(R.id.customTextView);
        mDefaultTextView = (TextView) findViewById(R.id.defaultTextView);
        mCustomButton = (Button) findViewById(R.id.customButton);

    }

    public void updateText(View v) {
        mSampleStr = mSampleText.getText().toString();

        mCustomTextView.setTextSize(mDefaultTextView.getTextSize());
        mCustomTextView.setMaxTextSize(mDefaultTextView.getTextSize());
        mCustomTextView.setMinTextSize(10.0f);
        mCustomTextView.setAddEllipsis(false);
        Log.i("####", "Defualt Text size : " + mDefaultTextView.getTextSize());

        mCustomTextView.setText(mSampleStr);
        mDefaultTextView.setText(mSampleStr);

        mCustomButton.setText(mSampleStr);
    }

}
