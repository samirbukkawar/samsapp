package sam.study.app;

/**
 * Created by samir.s.bukkawar on 11/29/2016.
 */

public class MainTestClass {

    public static void main(String[] args) {

        myClass myClassObj = new myClass();
        I2 i2 = new myClass();

        myClassObj.doStuff(i2);

        System.out.println("Hello Word");
    }
}

interface I1 {
    public void doStuff(Object i1);

}

interface I2 {
    public void doStuff(Object i2);

}

class myClass implements I1, I2 {


    @Override
    public void doStuff(Object obj) {
        System.out.println("Hello Word : " + obj.getClass());
    }
}
