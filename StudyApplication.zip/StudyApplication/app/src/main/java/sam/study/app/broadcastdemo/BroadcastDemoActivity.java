package sam.study.app.broadcastdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import sam.study.app.R;

public class BroadcastDemoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcast_demo);

        final Button registerReceiver = (Button) findViewById(R.id.registerReceiver);
        registerReceiver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //MyCallReceiver myCallReceiver = registerReceiver.
            }
        });
    }

}
