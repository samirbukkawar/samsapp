package sam.study.app.crittercism;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.crittercism.app.Crittercism;

import org.acra.ACRA;

import sam.study.app.R;

public class CrittercismDemoActivity extends Activity {

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crittercism_demo);

        mContext = this;

        final Button registerCrittercism = (Button) findViewById(R.id.registerCrittercism);
        registerCrittercism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Crittercism.initialize(getApplicationContext(), "cd844f8322cb49f882579103d924f0a600555300");
            }
        });

        final Button createException = (Button) findViewById(R.id.createException);
        createException.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int test = 3 / 0;
                } catch (Exception e) {
                    e.printStackTrace();

                    ACRA.getErrorReporter().handleException(e);
                }
                Toast.makeText(mContext, " Crittersism Exception created", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
