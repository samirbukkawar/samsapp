package sam.study.app.realmdb;

import android.app.Activity;
import android.os.Bundle;

import sam.study.app.R;

public class RealmDemoAvtivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realm_demo);
    }
}
