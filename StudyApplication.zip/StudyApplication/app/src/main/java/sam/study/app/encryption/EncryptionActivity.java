package sam.study.app.encryption;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import sam.study.app.R;

public class EncryptionActivity extends Activity {

    private EditText encryptText;
    private TextView tvEncryptedText, tvDecryptedText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encryption);

        encryptText = (EditText) findViewById(R.id.etEncryptText);
        tvEncryptedText = (TextView) findViewById(R.id.tvEncryptedText);
        tvDecryptedText = (TextView) findViewById(R.id.tvDecryptedText);


        Button b1 = (Button) findViewById(R.id.btnSubmit);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                byte[] encryptedText = EncryptUtil.getEncryptedData(encryptText.getText().toString());
                tvEncryptedText.setText(encryptedText.toString());

                try {
                    tvDecryptedText.setText(EncryptUtil.getDecryptedData(encryptedText));
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }
}
