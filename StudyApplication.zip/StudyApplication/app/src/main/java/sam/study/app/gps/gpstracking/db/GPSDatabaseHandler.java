package sam.study.app.gps.gpstracking.db;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * 
 * This class is a subclass of SQLiteOpenHelper. This class is responsible for
 * creating the database. It also defines several constants for the table name
 * and the table columns
 * 
 * @author Shahnawaz Jafri/Samir Bukkawar
 *
 */
public class GPSDatabaseHandler extends SQLiteOpenHelper {

	public static final String TABLE_GPSRECORDS = "TBLGPSRECORDS";
	public static final String COLUMN_ID = "SR_NO";
	public static final String COLUMN_LONGITUDE = "LONGITUDE";
	public static final String COLUMN_LATTITUDE = "LATTITUDE";
	public static final String COLUMN_TIMESTAMP = "TIMESTAMP";

	private static final String DATABASE_NAME = "DBGPSRECORD.db";
	private static final int DATABASE_VERSION = 1;

	// Database creation SQL statement
	private static final String DATABASE_CREATE = "create table "
			+ TABLE_GPSRECORDS + "(" + COLUMN_ID
			+ " integer primary key autoincrement, " + COLUMN_LONGITUDE
			+ " text , " + COLUMN_LATTITUDE + " text, " + COLUMN_TIMESTAMP
			+ " text);";

	public GPSDatabaseHandler(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(DATABASE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(GPSDatabaseHandler.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_GPSRECORDS);
		onCreate(db);
	}

	// Adding new GPSRecord
	public void addGPSRecord(GPSRecord gpsRecords) {

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues conValues = new ContentValues();

		conValues.put(COLUMN_LATTITUDE, gpsRecords.getLattitude());
		conValues.put(COLUMN_LONGITUDE, gpsRecords.getLongitude());
		conValues.put(COLUMN_TIMESTAMP, gpsRecords.getTimestamp());

		// Inserting Row
		db.insert(TABLE_GPSRECORDS, null, conValues);
		// Closing database connection
		db.close();
	}

	// Getting All Contacts
	public Cursor getGPSRecords() {
		String selectQuery = "SELECT  * FROM " + TABLE_GPSRECORDS;

		SQLiteDatabase db = this.getWritableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		return cursor;
	}

	// Getting All Contacts
	public List<GPSRecord> getAllGPSRecords() {

		List<GPSRecord> gpsRecordList = new ArrayList<GPSRecord>();
		// Select All Query
		String selectQuery = "SELECT  * FROM " + TABLE_GPSRECORDS;

		SQLiteDatabase db = this.getWritableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);

		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				GPSRecord gpsRecord = new GPSRecord();
				gpsRecord.setId(Integer.parseInt(cursor.getString(0)));
				gpsRecord.setLongitude(cursor.getString(1));
				gpsRecord.setLattitude(cursor.getString(2));
				gpsRecord.setTimestamp(cursor.getString(3));

				gpsRecordList.add(gpsRecord);
			} while (cursor.moveToNext());
		}

		// return contact list
		return gpsRecordList;
	}

	// Deleting all records
	public void resetAllRecords() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TABLE_GPSRECORDS, null, null);
		db.close();
	}
}
