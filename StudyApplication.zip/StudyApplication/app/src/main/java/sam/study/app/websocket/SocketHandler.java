package sam.study.app.websocket;


import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import sam.study.app.StudyApplication;

/**
 * Created by samir.s.bukkawar on 2/18/2017.
 */

public class SocketHandler extends Handler {
    int i = 0;

    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Log.i("####", "handleMessage : Message >> " + msg.toString());
        Bundle b = msg.getData();

        Log.i("####", "bundle " + i++ + ">> " + b.get("RESPONSE_MESSAGE"));

        Context context = StudyApplication.getAppContext();

        /*
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
               // textInfo.setText("Message 1");
            }
        });*/


    }

}
