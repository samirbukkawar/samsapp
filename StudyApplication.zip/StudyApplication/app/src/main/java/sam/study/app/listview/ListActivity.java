package sam.study.app.listview;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import sam.study.app.R;

public class ListActivity extends Activity {

    ListView listView;
    String titleArray[] = {"Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"};
    String subTitleArray[] = {"Sub - Title 1", "Sub - Title 2", "Sub - Title 3", "Sub - Title 4", "Sub - Title 5", "Sub - Title 6"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);


        listView = (ListView) findViewById(R.id.myListView);
        // listView.setAdapter(new CustomAdapter());
        listView.setAdapter(new CustomAdapter(this, titleArray, subTitleArray));
    }
}