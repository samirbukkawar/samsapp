package sam.study.app.recycleviewdemo;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import sam.study.app.R;
import sam.study.app.model.Movie;

public class RecycleViewActivity extends Activity implements RecycleClickListner {

    private List<Movie> mMovieList = new ArrayList<>();
    private RecycleViewAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_view);

        prepareMovieData();

        RecyclerView recycleView = (RecyclerView) findViewById(R.id.my_recycle_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recycleView.setLayoutManager(layoutManager);
        recycleView.setItemAnimator(new DefaultItemAnimator());

        mAdapter = new RecycleViewAdapter(mMovieList, this);
        recycleView.setAdapter(mAdapter);
        mAdapter.setClickListener(this);
    }

    @Override
    public void OnClick(View view, int position) {
        Movie movie = mMovieList.get(position);
        Log.i("movie.getTitle", movie.getTitle());
    }

    private void prepareMovieData() {
        Movie movie = new Movie("Mad Max: Fury Road", "Action & Adventure", "2015");
        mMovieList.add(movie);

        movie = new Movie("Inside Out", "Animation, Kids & Family", "2015");
        mMovieList.add(movie);

        movie = new Movie("Star Wars: Episode VII - The Force Awakens", "Action", "2015");
        mMovieList.add(movie);

        movie = new Movie("Shaun the Sheep", "Animation", "2015");
        mMovieList.add(movie);

        movie = new Movie("The Martian", "Science Fiction & Fantasy", "2015");
        mMovieList.add(movie);

        movie = new Movie("Mission: Impossible Rogue Nation", "Action", "2015");
        mMovieList.add(movie);

        movie = new Movie("Up", "Animation", "2009");
        mMovieList.add(movie);

        movie = new Movie("Star Trek", "Science Fiction", "2009");
        mMovieList.add(movie);

        movie = new Movie("The LEGO Movie", "Animation", "2014");
        mMovieList.add(movie);

        movie = new Movie("Iron Man", "Action & Adventure", "2008");
        mMovieList.add(movie);

        movie = new Movie("Aliens", "Science Fiction", "1986");
        mMovieList.add(movie);

        movie = new Movie("Chicken Run", "Animation", "2000");
        mMovieList.add(movie);

        movie = new Movie("Back to the Future", "Science Fiction", "1985");
        mMovieList.add(movie);

        movie = new Movie("Raiders of the Lost Ark", "Action & Adventure", "1981");
        mMovieList.add(movie);

        movie = new Movie("Goldfinger", "Action & Adventure", "1965");
        mMovieList.add(movie);

        movie = new Movie("Guardians of the Galaxy", "Science Fiction & Fantasy", "2014");
        mMovieList.add(movie);

        if (mAdapter != null)
            mAdapter.notifyDataSetChanged();
    }

}