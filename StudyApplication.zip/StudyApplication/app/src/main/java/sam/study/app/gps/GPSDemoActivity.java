package sam.study.app.gps;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import sam.study.app.R;
import sam.study.app.gps.gpstracking.ConstantsData;
import sam.study.app.gps.gpstracking.fileio.FileWriterclass;
import sam.study.app.gps.gpstracking.gps.GPSService;


public class GPSDemoActivity extends AppCompatActivity {

    private Button mStartButton, mStopButton, mExtractButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpsdemo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        mStartButton = (Button) findViewById(R.id.button1);
        mStopButton = (Button) findViewById(R.id.button2);
        mExtractButton = (Button) findViewById(R.id.button3);
        mStopButton.setEnabled(false);

        mStartButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GPSDemoActivity.this, GPSService.class);
                Bundle bundle = new Bundle();
                bundle.putFloat("MIN_DISTANCE_IN_METER_TO_FETCH_GPS",
                        10);
                // 10000 MiliSec = 10 Sec
                bundle.putLong(ConstantsData.MIN_TIME_IN_MILISEC_TO_FETCH_GPS,
                        10000);

                // Set the criteria false - ACCURACY_COARSE and true -
                // ACCURACY_FINE
                bundle.putBoolean(ConstantsData.ACCURACY_CRITERIA_FLAG, true);
                intent.putExtra("bundle", bundle);

                startService(intent);
                mStopButton.setEnabled(true);
                mStartButton.setEnabled(false);
            }
        });

        mStopButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(GPSDemoActivity.this, GPSService.class);
                stopService(intent);
                mStopButton.setEnabled(false);
                mStartButton.setEnabled(true);
            }
        });

        mExtractButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Log.d("GPSservice", "File Extracting...");
                FileWriterclass fileWriter = new FileWriterclass("GPSDATA",
                        "GPSRecord");
                fileWriter.fileWrite(getApplicationContext());

            }
        });

    }

}