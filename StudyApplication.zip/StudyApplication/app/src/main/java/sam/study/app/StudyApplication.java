package sam.study.app;

import android.app.Application;
import android.content.Context;

import org.acra.ACRA;
import org.acra.ReportField;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;
import org.acra.config.ACRAConfiguration;


/**
 * Created by samir.s.bukkawar on 12/8/2016.
 */

@ReportsCrashes(
        customReportContent = {ReportField.APP_VERSION_CODE, ReportField.APP_VERSION_NAME, ReportField.ANDROID_VERSION, ReportField.PHONE_MODEL, ReportField.CUSTOM_DATA, ReportField.STACK_TRACE, ReportField.LOGCAT},
        mode = ReportingInteractionMode.TOAST,
        resToastText = R.string.crash_toast_text)

public class StudyApplication extends Application {

    StudyApplication mAppInstance;
    private static Context mContext;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        final ACRAConfiguration config;
        try {
            // The following line triggers the initialization of ACRA
            ACRA.init(this);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onCreate() {

        //ACRA.init(this);
        //MyOwnSender yourSender = new MyOwnSender(this);
        // ACRA.getErrorReporter().setReportSender(yourSender);

        super.onCreate();

        mContext = getApplicationContext();
    }

    public static Context getAppContext() {
        return mContext;
    }
}