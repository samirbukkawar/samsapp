package sam.study.app.gps.gpstracking.db;

/**
 * 
 * This class is a model and contains the data that will save in the database.
 * 
 * @author Shahnawaz Jafri/Samir Bukkawar
 *
 */
public class GPSRecord {

	int id;
	String longitude;
	String lattitude;
	String timestamp;

	// Empty constructor
	public GPSRecord() {

	}

	// Overloaded constructor
	public GPSRecord(String longitude, String lattitude, String timestamp) {
		this.longitude = longitude;
		this.lattitude = lattitude;
		this.timestamp = timestamp;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLattitude() {
		return lattitude;
	}

	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
}
