package sam.study.app.recycleviewdemo;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.List;

import sam.study.app.R;
import sam.study.app.model.Movie;

/**
 * Created by samir.s.bukkawar on 11/16/2016.
 */

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> {

    private List<Movie> moviesList;
    private Context mContext;
    private View mItemView;
    private RecycleClickListner mClickListner;

    public void setClickListener(RecycleClickListner clickListener) {
        this.mClickListner = clickListener;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView title, year, genre;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.titleView);
            genre = (TextView) view.findViewById(R.id.genreView);
            year = (TextView) view.findViewById(R.id.yearView);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListner != null) {
                mClickListner.OnClick(view, getAdapterPosition());
            }
        }
    }

    public RecycleViewAdapter(List<Movie> moviesList, Activity activity) {
        this.moviesList = moviesList;
        mContext = activity;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mItemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.content_recycle_view, parent, false);

        return new MyViewHolder(mItemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Movie movie = moviesList.get(position);
        holder.title.setText(movie.getTitle());
        holder.genre.setText(movie.getGenre());
        holder.year.setText(movie.getYear());

    }

    @Override
    public int getItemCount() {
        WeakReference weakReference = new WeakReference(moviesList);
        weakReference.get();
        return moviesList.size();
    }
}