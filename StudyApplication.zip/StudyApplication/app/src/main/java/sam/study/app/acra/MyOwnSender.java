package sam.study.app.acra;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;

import org.acra.collector.CrashReportData;
import org.acra.sender.ReportSender;
import org.acra.sender.ReportSenderException;

/**
 * Created by samir.s.bukkawar on 12/8/2016.
 */

public class MyOwnSender implements ReportSender {

    public MyOwnSender(Context context) {
        // initialize your sender with needed parameters
        Log.i("MyOwnSender", "MyOwnSender : " + context.getClass());
    }

    @Override
    public void send(@NonNull Context context, @NonNull CrashReportData errorContent) throws ReportSenderException {
        Log.i("MyOwnSender", "CrashReportData : " + errorContent.toString());
    }
}
