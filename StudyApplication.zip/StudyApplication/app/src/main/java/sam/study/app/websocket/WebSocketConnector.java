package sam.study.app.websocket;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.apache.http.message.BasicNameValuePair;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import sam.study.app.HandlerLooper.HandlerLooperActivity;

/**
 * Created by samir.s.bukkawar on 2/18/2017.
 */


public class WebSocketConnector {

    String TAG = "****";
    String webSocketURL = "ws://www.servicepoint.live:8080/ws";
    List<BasicNameValuePair> extraHeaders;

    SocketThread myThread;

    public void ConnectWebSocket() {

        myThread = new SocketThread();
        myThread.start();

        // List<BasicNameValuePair> extraHeaders = Arrays.asList(new BasicNameValuePair("Cookie", "session=abcd"));\
        List<BasicNameValuePair> extraHeaders = new ArrayList<BasicNameValuePair>();

        URI testUri = URI.create(webSocketURL);
        final WebSocketClient client = new WebSocketClient(testUri, new WebSocketClient.Listener() {

            @Override
            public void onConnect() {
                Log.d(TAG, "Connected!");

            }

            @Override
            public void onMessage(String strRespone) {
                Log.d(TAG, String.format("Got string message! %s" + strRespone, strRespone));

                myThread.handler.obtainMessage(1, strRespone);

                Message message;
                message = myThread.handler.obtainMessage(1, SocketThread.responseString);
                Bundle b = new Bundle();
                b.putString("RESPONSE_MESSAGE", strRespone);
                message.setData(b);
                myThread.handler.sendMessage(message);
            }

            @Override
            public void onMessage(byte[] data) {
                // Log.d(TAG, String.format("Got binary message! %s", data.toString());
                //downloadThread.enqueueDownload(new DownloadTask());
            }

            @Override
            public void onDisconnect(int code, String reason) {
                Log.d(TAG, String.format("Disconnected! Code: %d Reason: %s", code, reason));
            }

            @Override
            public void onError(Exception error) {
                Log.e(TAG, "Error!" + error, error);
            }

        }, extraHeaders);

        client.connect();


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                // buttons[inew][jnew].setBackgroundColor(Color.BLACK);
                //Device autheticate
                String s1 = "{\"header\":{\"crc\":\"12\",\"category\":1,\"commandid\":1,\"seqid\":3},\"payload\":{\"serialno\":\"P314140131054003\"}}";
                String s2 = "{\"header\":{\"crc\":\"12\",\"category\":2,\"commandid\":1,\"seqid\":3},\"payload\":{}}";
                client.send(s1);
                client.send(s2);
            }
        }, 3000);

    }

}
