package sam.study.app.broadcastdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by samir.s.bukkawar on 12/6/2016.
 */

public class MyCallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "This is My receiver", Toast.LENGTH_SHORT).show();
    }
}
