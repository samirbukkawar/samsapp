package sam.study.app.gps.gpstracking.gps;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import sam.study.app.R;

/**
 * This class implements the LocationListener and respective override methods.
 * This class will retrieve the GPS location as per given Criteria
 *
 * @author Shahnawaz Jafri/Samir Bukkawar
 */
public class GPSTracker implements LocationListener {

    private final Context mContext;
    private final String GPS_NOTIFICATION_TITLE = "GPS Tracker";
    private final String GPS_NOTIFICATION_TEXT = "Please enable your GPS setting";

    // flag for GPS status
    boolean isGPSEnabled = false;

    // flag for GPS status
    boolean canGetLocation = false;

    Location location;
    double latitude, longitude;

    // Declaring a Location Manager
    protected LocationManager locationManager;

    public GPSTracker(Context context, float minDistance, long minTime,
                      boolean isAccuracyFine) {
        this.mContext = context;
        getLocation(minDistance, minTime, isAccuracyFine);
    }

    /**
     * Returns GPS location as per given <strong>minDistance</strong> and
     * <strong>minTime</strong> Also it will track the GPS location as per given
     * <strong>isAccuracyFine</strong> flag
     *
     * @param minDistance    - minimum distance between location updates, in meters
     * @param minTime        - minimum time interval between location updates, in
     *                       milliseconds
     * @param isAccuracyFine <br>
     *                       false - ACCURACY_COARSE<br>
     *                       true - ACCURACY_FINE<br>
     * @return Location - Current GPS location
     */
    public Location getLocation(float minDistance, long minTime,
                                boolean isAccuracyFine) {
        try {
            locationManager = (LocationManager) mContext
                    .getSystemService(Service.LOCATION_SERVICE);

            // getting GPS status
            isGPSEnabled = locationManager
                    .isProviderEnabled(LocationManager.GPS_PROVIDER);

            if (!isGPSEnabled) {
                // no network provider is enabled
                showGPSAlert();

            } else {
                this.canGetLocation = true;

                // if GPS Enabled get lat/long using GPS Services
                if (isGPSEnabled) {
                    if (location == null) {
                        locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER, minTime,
                                minDistance, this);
                        Log.d("GPS Enabled", "GPS Enabled");
                        if (locationManager != null) {
                            Criteria criteria = new Criteria();

                            if (isAccuracyFine)
                                criteria.setAccuracy(Criteria.ACCURACY_FINE);
                            else
                                criteria.setAccuracy(Criteria.ACCURACY_COARSE);

                            String bestprovider = locationManager
                                    .getBestProvider(criteria, true);
                            location = locationManager
                                    .getLastKnownLocation(bestprovider);
                            if (location != null) {
                                latitude = location.getLatitude();
                                longitude = location.getLongitude();
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return location;
    }

    /**
     * Stop using GPS listener Calling this function will stop using GPS in your
     * app
     */
    public void stopUsingGPS() {
        if (locationManager != null) {
            locationManager.removeUpdates(GPSTracker.this);
        }
    }

    /**
     * Function to get latitude
     */
    public double getLatitude() {
        if (location != null) {
            latitude = location.getLatitude();
        }

        // return latitude
        return latitude;
    }

    /**
     * Function to get longitude
     */
    public double getLongitude() {
        if (location != null) {
            longitude = location.getLongitude();
        }

        // return longitude
        return longitude;
    }

    /**
     * Function to check GPS/wifi enabled
     *
     * @return boolean
     */
    public boolean canGetLocation() {
        return this.canGetLocation;
    }


    /**
     * Function to show settings alert dialog On pressing Settings button will
     * lauch Settings Options
     */

    @SuppressWarnings("deprecation")
    @SuppressLint("NewApi")
    public void showGPSAlert() {

        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, intent,
                0);

        // build notification
        // the addAction re-use the same intent to keep the example short
        Notification n;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            n = new Notification.Builder(mContext)
                    .setContentTitle(GPS_NOTIFICATION_TITLE)
                    .setContentText(GPS_NOTIFICATION_TEXT)
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setContentIntent(pIntent).setAutoCancel(true).build();
        } else {
            n = new Notification.Builder(mContext)
                    .setContentTitle(GPS_NOTIFICATION_TITLE)
                    .setContentText(GPS_NOTIFICATION_TEXT)
                    .setSmallIcon(R.drawable.ic_launcher).getNotification();
        }

        NotificationManager notificationManager = (NotificationManager) mContext
                .getSystemService(Service.NOTIFICATION_SERVICE);

        notificationManager.notify(0, n);
    }

    @Override
    public void onLocationChanged(Location location) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

}
