package com.example.gpstrackingdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.example.gpstracking.ConstantsData;
import com.example.gpstracking.fileio.FileWriterclass;
import com.example.gpstracking.gps.GPSService;

public class MainActivity extends Activity {

	private Button mStartButton, mStopButton, mExtractButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mStartButton = (Button) findViewById(R.id.button1);
		mStopButton = (Button) findViewById(R.id.button2);
		mExtractButton = (Button) findViewById(R.id.button3);
		mStopButton.setEnabled(false);

		mStartButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, GPSService.class);
				Bundle bundle = new Bundle();
				bundle.putFloat("MIN_DISTANCE_IN_METER_TO_FETCH_GPS",
						10);
				// 10000 MiliSec = 10 Sec
				bundle.putLong(ConstantsData.MIN_TIME_IN_MILISEC_TO_FETCH_GPS,
						10000);

				// Set the criteria false - ACCURACY_COARSE and true -
				// ACCURACY_FINE
				bundle.putBoolean(ConstantsData.ACCURACY_CRITERIA_FLAG, true);
				intent.putExtra("bundle", bundle);

				startService(intent);
				mStopButton.setEnabled(true);
				mStartButton.setEnabled(false);
			}
		});

		mStopButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent intent = new Intent(MainActivity.this, GPSService.class);
				stopService(intent);
				mStopButton.setEnabled(false);
				mStartButton.setEnabled(true);
			}
		});

		mExtractButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				Log.d("GPSservice", "File Extracting...");
				FileWriterclass fileWriter = new FileWriterclass("GPSDATA",
						"GPSRecord");
				fileWriter.fileWrite(getApplicationContext());

			}
		});

	}
}
